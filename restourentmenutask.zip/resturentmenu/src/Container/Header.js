import React from 'react';

const Header = () => {
  // Handle click for the Restaurant link
  const handleRestaurantClick = (event) => {
    event.preventDefault(); // Prevent default action
    // Handle any other logic for the click event
  };

  // Handle click for the Orders button
  const handleOrdersClick = (event) => {
    // Handle any logic for the Orders click
  };

  return (
    <div>
      <nav className='navbar-light bg-light'>
        {/* Use href="#" and onClick to prevent default action */}
        <h1 className='navbar-brand' onClick={handleRestaurantClick}>
          Restaurant
        </h1>
        {/* Adjust the button to behave as a link */}
       <h1><button className='btn btn-link' onClick={handleOrdersClick}>
          Orders <span className='badge bg-secondary'>0</span>
        </button>
        </h1> 
      </nav>
    </div>
  );
};

export default Header;
