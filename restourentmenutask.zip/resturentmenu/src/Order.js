import React from 'react'

const Order = () => {
  return (
    <div>
      <center>
       <h4>Order Components</h4> 
      </center>
    </div>
  )
}

export default Order
