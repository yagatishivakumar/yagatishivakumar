// bankAccount.ts

import { AccountDetails } from '../src/models/accountDetails';

export class BankAccount {
  private accountDetails: AccountDetails | null = null;
  private balance: number = 0;

  public openAccount(details: AccountDetails): void {
    this.accountDetails = details;
    this.balance = details.initialBalance;
  }

  public getAccountDetails(): AccountDetails | null {
    return this.accountDetails;
  }

  public depositMoney(amount: number): void {
    if (this.accountDetails) {
      this.balance += amount;
    }
  }

  public withdrawMoney(amount: number): void {
    if (this.accountDetails) {
      this.balance -= amount;
    }
  }

  public getBalance(): number {
    return this.balance;
  }
}
