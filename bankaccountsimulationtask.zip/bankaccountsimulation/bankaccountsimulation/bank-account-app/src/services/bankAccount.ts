// src/services/bankAccount.ts

import { AccountDetails } from '../models/accountDetails';

export class BankAccount {
  private accountDetails: AccountDetails | null = null;
  private balance: number = 0;

  public openAccount(details: AccountDetails): void {
    this.accountDetails = details;
    this.balance = details.initialBalance;
  }

  public depositMoney(amount: number): void {
    if (this.accountDetails) {
      this.balance += amount;
    }
  }

  public withdrawMoney(amount: number): void {
    if (this.accountDetails) {
      this.balance -= amount;
    }
  }

  public getAccountDetails(): AccountDetails | null {
    return this.accountDetails;
  }

  public getBalance(): number {
    return this.balance;
  }
}
