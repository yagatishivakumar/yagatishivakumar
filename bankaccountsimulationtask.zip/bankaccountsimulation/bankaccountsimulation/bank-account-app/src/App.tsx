import React from 'react';
import './App.scss';
import BankAccountComponent from './components/BankAccountComponent';

const App: React.FC = () => {
  return (
    <div className="App">
      <BankAccountComponent />
    </div>
  );
};

export default App;