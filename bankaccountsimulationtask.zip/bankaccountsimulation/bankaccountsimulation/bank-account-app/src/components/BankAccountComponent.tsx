// BankAccountComponent.tsx

import React, { useState } from 'react';
import { BankAccount } from '../services/bankAccount';
import './BankAccountComponent.scss';

const BankAccountComponent: React.FC = () => {
  const [account, setAccount] = useState<BankAccount | null>(null);
  const [balance, setBalance] = useState<number>(0);

  const openAccount = () => {
    const newAccount = new BankAccount();
    newAccount.openAccount({
      name: "John Doe",
      gender: "Male",
      dob: new Date("1990-01-01"),
      email: "john.doe@example.com",
      mobile: "1234567890",
      address: "123 Main St",
      initialBalance: 1000,
      adharNo: "1234-5678-9012",
      panNo: "ABCDE1234F"
    });
    setAccount(newAccount);
    setBalance(1000);
  };

  const depositMoney = (amount: number) => {
    if (account) {
      account.depositMoney(amount);
      setBalance(balance + amount);
    }
  };

  const withdrawMoney = (amount: number) => {
    if (account) {
      account.withdrawMoney(amount);
      setBalance(balance - amount);
    }
  };

  return (
    <div className="bank-account">
      <h1>Bank Account Simulation</h1>
      
      {/* Display account details if account is open */}
      {account && account.getAccountDetails() && (
        <div className="account-details">
          <h2>Account Details:</h2>
          <p><strong>Name:</strong> {account.getAccountDetails()?.name}</p>
          <p><strong>Email:</strong> {account.getAccountDetails()?.email}</p>
          <p><strong>Date of Birth:</strong> {account.getAccountDetails()?.dob.toDateString()}</p>
          <p><strong>Mobile:</strong> {account.getAccountDetails()?.mobile}</p>
          
          {/* Add more details as needed */}
        </div>
      )}

      <button onClick={openAccount}>Open Account</button>
      <button onClick={() => depositMoney(500)}>Deposit $500</button>
      <button onClick={() => withdrawMoney(200)}>Withdraw $200</button>

      <h2>Balance: ${balance}</h2>
    </div>
  );
};

export default BankAccountComponent;
