import React from 'react';
import { render, screen } from '@testing-library/react';
import App from './App';

test('renders Bank Account Simulation header', () => {
  render(<App />);
  const headerElement = screen.getByText(/Bank Account Simulation/i);
  expect(headerElement).toBeInTheDocument();
});