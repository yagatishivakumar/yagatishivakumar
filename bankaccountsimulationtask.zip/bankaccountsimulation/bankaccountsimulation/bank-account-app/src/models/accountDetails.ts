// src/models/accountDetails.ts

export interface AccountDetails {
    name: string;
    gender: string;
    dob: Date;
    email: string;
    mobile: string;
    address: string;
    initialBalance: number;
    adharNo: string;
    panNo: string;
  }
  