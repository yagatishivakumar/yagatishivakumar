#!/usr/bin/env node

// Function to parse and perform the calculation
function calculate(question) {
    // Define regex patterns for supported operations
    const addPattern = /what is (\d+) plus (\d+)\?/i;
    const subtractPattern = /what is (\d+) minus (\d+)\?/i;
    const multiplyPattern = /what is (\d+) multiplied by (\d+)\?/i;
    const dividePattern = /what is (\d+) divided by (\d+)\?/i;

    let match;

    if (match = question.match(addPattern)) {
        const result = parseInt(match[1]) + parseInt(match[2]);
        return `${match[1]} plus ${match[2]} is ${result}`;
    } else if (match = question.match(subtractPattern)) {
        const result = parseInt(match[1]) - parseInt(match[2]);
        return `${match[1]} minus ${match[2]} is ${result}`;
    } else if (match = question.match(multiplyPattern)) {
        const result = parseInt(match[1]) * parseInt(match[2]);
        return `${match[1]} multiplied by ${match[2]} is ${result}`;
    } else if (match = question.match(dividePattern)) {
        const result = parseInt(match[1]) / parseInt(match[2]);
        return `${match[1]} divided by ${match[2]} is ${result}`;
    } else {
        return "Unsupported question format.";
    }
}

// Get the input question from the command line arguments
const question = process.argv.slice(2).join(" ");

if (question) {
    console.log(calculate(question));
} else {
    console.log("Please provide a question.");
}
